Sentinel Watch V15 — GitHub Pages Ready

Upload these files to the ROOT of a GitHub repository, then enable GitHub Pages:

Files:
- index.html
- manifest.json
- sw.js
- icon-192.png
- icon-512.png
- apple-touch-icon.png
- .nojekyll

GitHub Pages settings:
- Source: Deploy from branch
- Branch: main
- Folder: /root

After GitHub Pages is enabled, your app URL will be:
https://YOURUSERNAME.github.io/REPOSITORY-NAME/

On iPhone:
Open that URL in Safari, then tap Share → Add to Home Screen.
